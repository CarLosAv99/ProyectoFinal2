package Ventanas;

import Clases.matricula;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.Dimension;

public class Matricula extends javax.swing.JInternalFrame {
    private final matricula CP;
    TableColumnModel columnModel;
    public static String estudiante;
    public static String cedula;
    public static int[] id_periodo;
    
    DefaultTableModel DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
    
    public Matricula() {
        initComponents();
        CP = new matricula();
        bt_buscar.setEnabled(false);
        bt_guardar.setEnabled(false);
        bt_cancelar.setEnabled(false);
        bt_agregar.setEnabled(false);
        bt_quitar.setEnabled(false);
        listar();
        desactivar();
        
        CP.carreras_disponibles(cb_carrera);
        CP.periodos_disponibles(cb_periodos);
        CP.niveles_disponibles(cb_nivel);
        
        String carr = (String)cb_carrera.getSelectedItem();
        String nivv = (String)cb_nivel.getSelectedItem();
        CP.materias_disponibles(cb_materias, carr, nivv);
        
        cb_carrera.addItemListener( new ItemListener(){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if ( e.getStateChange() == ItemEvent.SELECTED ) 
                {
                    cb_materias.removeAllItems();
                    cb_materias.addItem("Seleccione materias");
                    String car = (String)cb_carrera.getSelectedItem();
                    String niv = (String)cb_nivel.getSelectedItem();
                    CP.materias_disponibles(cb_materias, car, niv);
                }
            }

        });
        
        cb_nivel.addItemListener( new ItemListener(){
            @Override
            public void itemStateChanged(ItemEvent e) {
                if ( e.getStateChange() == ItemEvent.SELECTED ) 
                {
                    cb_materias.removeAllItems();
                    cb_materias.addItem("Seleccione materias");
                    String car = (String)cb_carrera.getSelectedItem();
                    String niv = (String)cb_nivel.getSelectedItem();
                    CP.materias_disponibles(cb_materias, car, niv);
                }
            }

        });
    }
    
    private void listar(){
        DT.addColumn("Materia");
        DT.addColumn("Nivel");
        this.tabla.setModel(DT);
    }
    
    private void desactivar(){
        tf_estudiante.setEnabled(false);
        cb_carrera.setEnabled(false);
        cb_materias.setEnabled(false);
        cb_nivel.setEnabled(false);
        cb_periodos.setEnabled(false);
        bt_nuevo.setEnabled(true);
        bt_guardar.setEnabled(false);
        bt_agregar.setEnabled(false);
        bt_quitar.setEnabled(false);
        bt_buscar.setEnabled(false);
        tf_estudiante.setText("");
        bt_cancelar.setEnabled(false);
        cb_carrera.setSelectedIndex(0);
        cb_materias.setSelectedIndex(0);
        cb_nivel.setSelectedIndex(0);
        cb_periodos.setSelectedIndex(0);
    }
    
    private void activar(){
        tf_estudiante.setEnabled(true);
        cb_carrera.setEnabled(true);
        cb_materias.setEnabled(true);
        cb_nivel.setEnabled(true);
        cb_periodos.setEnabled(true);
    }
    
    private int validarCampos(){
        int aux = 0;
   
        if(tf_estudiante.getText().isEmpty()) aux = 1;
        if(cb_carrera.getSelectedItem().toString().isEmpty()) aux = 1;
        if(cb_nivel.getSelectedItem().toString().isEmpty()) aux = 1;
        if(cb_periodos.getSelectedItem().toString().isEmpty()) aux = 1;
        if(cb_materias.getSelectedItem().toString().isEmpty()) aux = 1;
        
        if (aux == 1)
            JOptionPane.showMessageDialog(null, "No deben existir campos vacios");
        
        return aux;
    }
    
    private void limpiar(){ 
        tf_estudiante.setText("");
        
        DefaultTableModel modelo=(DefaultTableModel) tabla.getModel();
            int filas=tabla.getRowCount();
            
            for (int i = 0;filas>i; i++) {
                modelo.removeRow(0);
            }
    }
    
    private void guardar(){
        String semestr = (String)cb_nivel.getSelectedItem();
        int sem = CP.idSemestre(semestr);
        
        String carr = (String)cb_carrera.getSelectedItem();
        int car = CP.idCarrera(carr);
        
        int index_Periodo = cb_periodos.getSelectedIndex();
        
        int filas = tabla.getRowCount();
        
        if(filas > 0){
            int respuesta = CP.registrarMatricula(cedula,id_periodo[index_Periodo], sem, car);
            
            if(respuesta > 0){
                int idMat = CP.idUltimaMatricula();
                guardarMatricula_Mat(idMat);
                limpiar();
                desactivar();
            }
        }
        
        else{
            JOptionPane.showMessageDialog(null, "Debe agregar materias.");
        }
    }
    
    private void guardarMatricula_Mat(int id_matricula){
        for (int i = 0; i < tabla.getRowCount(); i++){
            String materia = tabla.getValueAt(i, 0).toString();
            String id_mat = CP.idMateria(materia);
            CP.guardarMatricula_Materias(id_mat, id_matricula);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tf_estudiante = new javax.swing.JTextField();
        cb_nivel = new javax.swing.JComboBox<>();
        cb_periodos = new javax.swing.JComboBox<>();
        cb_carrera = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        cb_materias = new javax.swing.JComboBox<>();
        bt_agregar = new javax.swing.JButton();
        bt_buscar = new javax.swing.JButton();
        bt_quitar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        bt_guardar = new javax.swing.JButton();
        bt_cancelar = new javax.swing.JButton();
        bt_nuevo = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setTitle("Matriculación");

        jPanel1.setBackground(new java.awt.Color(251, 248, 248));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED)), "Datos de Matricula", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jLabel1.setText("Estudiante");

        jLabel2.setText("Carrera");

        jLabel3.setText("Período");

        jLabel4.setText("Nivel");

        tf_estudiante.setEditable(false);

        cb_nivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un nivel" }));

        cb_periodos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione período" }));
        cb_periodos.setToolTipText("");
        cb_periodos.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                cb_periodosAncestorMoved(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        cb_carrera.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una carrera" }));
        cb_carrera.setToolTipText("");
        cb_carrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_carreraActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla);

        jLabel5.setText("Materias");

        cb_materias.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione materias" }));

        bt_agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/agg.png"))); // NOI18N
        bt_agregar.setContentAreaFilled(false);
        bt_agregar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_agregarActionPerformed(evt);
            }
        });

        bt_buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/lupa.png"))); // NOI18N
        bt_buscar.setContentAreaFilled(false);
        bt_buscar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_buscarActionPerformed(evt);
            }
        });

        bt_quitar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/quitar.png"))); // NOI18N
        bt_quitar.setContentAreaFilled(false);
        bt_quitar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_quitar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_quitarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cb_materias, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(bt_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bt_quitar, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(cb_carrera, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(tf_estudiante, javax.swing.GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bt_buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(63, 63, 63)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(15, 15, 15)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cb_periodos, javax.swing.GroupLayout.Alignment.LEADING, 0, 230, Short.MAX_VALUE)
                            .addComponent(cb_nivel, javax.swing.GroupLayout.Alignment.LEADING, 0, 230, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bt_buscar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel1)
                                .addComponent(tf_estudiante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(cb_carrera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cb_nivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cb_periodos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(cb_materias, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(bt_agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bt_quitar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(251, 248, 248));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        bt_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/agregarp.png"))); // NOI18N
        bt_guardar.setText("Guardar Inscripción");
        bt_guardar.setBorderPainted(false);
        bt_guardar.setContentAreaFilled(false);
        bt_guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_guardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_guardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_guardarActionPerformed(evt);
            }
        });

        bt_cancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/cancelar.png"))); // NOI18N
        bt_cancelar.setText("Cancelar");
        bt_cancelar.setContentAreaFilled(false);
        bt_cancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_cancelar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_cancelar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_cancelarActionPerformed(evt);
            }
        });

        bt_nuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/nuevav.png"))); // NOI18N
        bt_nuevo.setText("Nueva Inscripción");
        bt_nuevo.setContentAreaFilled(false);
        bt_nuevo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_nuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_nuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_nuevoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bt_nuevo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bt_guardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(bt_cancelar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(bt_nuevo)
                .addGap(27, 27, 27)
                .addComponent(bt_guardar)
                .addGap(31, 31, 31)
                .addComponent(bt_cancelar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_buscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_buscarActionPerformed
        BuscarEstudiantes C = new BuscarEstudiantes();
        Ventanas.Principal.contenedor.add(C);
        Dimension desktopSize = Principal.contenedor.getSize();
        Dimension FrameSize = C.getSize();
        C.setLocation((desktopSize.width - FrameSize.width)/2, (desktopSize.height- FrameSize.height)/2);
        C.toFront();
        C.setVisible(true);
    }//GEN-LAST:event_bt_buscarActionPerformed

    private void cb_carreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_carreraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_carreraActionPerformed

    private void bt_agregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_agregarActionPerformed
        int aux = 0, filas;
        filas = DT.getRowCount();
        
        if(cb_materias.getSelectedIndex() == 0){
            JOptionPane.showMessageDialog(null, "Seleccione materias");
        }
        
        else{
            if(filas > 0){
                for (int i = 0; i < DT.getRowCount(); i++){
                    if(cb_materias.getSelectedItem().equals(tabla.getValueAt(i, 0).toString())){
                        aux = 1;
                    }
                }
            }
            
            if(aux == 0){
                Object vector[]= new Object[2];
                vector[0] = (String)cb_materias.getSelectedItem();
                vector[1] = (String)cb_nivel.getSelectedItem();
                DT.addRow(vector);
            }
            
            else{
                JOptionPane.showMessageDialog(null, "La materia ya se encuentra agregada.");
            }
            
        }
        
    }//GEN-LAST:event_bt_agregarActionPerformed

    private void bt_cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_cancelarActionPerformed
        int resp = JOptionPane.showConfirmDialog(null, "¿Cancelar Inscripción?", "Alerta!", JOptionPane.YES_NO_OPTION);
        
        if(resp == 0){
            limpiar();
            desactivar();
        }
    }//GEN-LAST:event_bt_cancelarActionPerformed

    private void bt_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_guardarActionPerformed
        int resp = validarCampos();
        int existe = CP.cedulaRepetida(cedula);
        
        if(resp == 0){
            int fila = tabla.getSelectedRowCount();
            if (fila < 1 && existe == 0){
                guardar();
            }
            else{
                JOptionPane.showMessageDialog(null, "El estudiante ya se encuentra matriculado.");
            }
        }
    }//GEN-LAST:event_bt_guardarActionPerformed

    private void bt_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_nuevoActionPerformed
        bt_buscar.setEnabled(true);
        bt_guardar.setEnabled(true);
        bt_agregar.setEnabled(true);
        bt_quitar.setEnabled(true);
        bt_nuevo.setEnabled(false);
        bt_cancelar.setEnabled(true);
        activar();
        limpiar();
    }//GEN-LAST:event_bt_nuevoActionPerformed

    private void bt_quitarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_quitarActionPerformed
        int fila = tabla.getSelectedRowCount();
        if (fila < 1){
            JOptionPane.showMessageDialog(null, "Seleccione un registro de la tabla");
        }
        else{
            DT.removeRow(tabla.getSelectedRow());
        }
    }//GEN-LAST:event_bt_quitarActionPerformed

    private void cb_periodosAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_cb_periodosAncestorMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_periodosAncestorMoved

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_agregar;
    private javax.swing.JButton bt_buscar;
    private javax.swing.JButton bt_cancelar;
    private javax.swing.JButton bt_guardar;
    private javax.swing.JButton bt_nuevo;
    private javax.swing.JButton bt_quitar;
    private javax.swing.JComboBox<String> cb_carrera;
    private javax.swing.JComboBox<String> cb_materias;
    private javax.swing.JComboBox<String> cb_nivel;
    private javax.swing.JComboBox<String> cb_periodos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    public static javax.swing.JTextField tf_estudiante;
    // End of variables declaration//GEN-END:variables
}
