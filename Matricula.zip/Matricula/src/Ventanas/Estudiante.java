package Ventanas;

import Clases.Estudiantes;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumnModel;


public class Estudiante extends javax.swing.JInternalFrame {
    private final Estudiantes CP;
    TableColumnModel columnModel;
    
    public Estudiante() {
        initComponents();
        CP = new Estudiantes();
        columnModel = tabla.getColumnModel();
        listar();
        bt_actualizar.setEnabled(false);
        bt_eliminar.setEnabled(false);
        bt_guardar.setEnabled(false);
        desactivar();
    }
    
    private void listar(){
        tabla.setModel(CP.getDatosEstudiante());
        columnModel.getColumn(0).setPreferredWidth(40);
        columnModel.getColumn(1).setPreferredWidth(75);
        columnModel.getColumn(2).setPreferredWidth(75);
        columnModel.getColumn(3).setPreferredWidth(20);
        columnModel.getColumn(4).setPreferredWidth(125);
        columnModel.getColumn(5).setPreferredWidth(20);
        columnModel.getColumn(6).setPreferredWidth(20);
        columnModel.getColumn(7).setPreferredWidth(20);
    }
    
    private void desactivar(){
        tf_cedula.setEnabled(false);
        tf_nombres.setEnabled(false);
        tf_apellidos.setEnabled(false);
        tf_edad.setEnabled(false);
        tf_direccion.setEnabled(false);
        tf_estado_civil.setEnabled(false);
        cb_genero.setEnabled(false);
        tf_telefono.setEnabled(false);
        tf_correo.setEnabled(false);
    }
    
    private void activar(){
        tf_cedula.setEnabled(true);
        tf_nombres.setEnabled(true);
        tf_apellidos.setEnabled(true);
        tf_edad.setEnabled(true);
        tf_direccion.setEnabled(true);
        tf_estado_civil.setEnabled(true);
        cb_genero.setEnabled(true);
        tf_telefono.setEnabled(true);
        tf_correo.setEnabled(true);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tf_cedula = new javax.swing.JTextField();
        tf_nombres = new javax.swing.JTextField();
        tf_apellidos = new javax.swing.JTextField();
        tf_edad = new javax.swing.JTextField();
        tf_direccion = new javax.swing.JTextField();
        tf_estado_civil = new javax.swing.JTextField();
        cb_genero = new javax.swing.JComboBox<>();
        tf_telefono = new javax.swing.JTextField();
        tf_correo = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        bt_guardar = new javax.swing.JButton();
        bt_actualizar = new javax.swing.JButton();
        bt_eliminar = new javax.swing.JButton();
        bt_limpiar = new javax.swing.JButton();

        setBackground(new java.awt.Color(251, 248, 248));
        setClosable(true);
        setIconifiable(true);
        setTitle("Estudiantes");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Estudiantes Registrados", jPanel2);

        jPanel3.setBackground(new java.awt.Color(251, 248, 248));

        jLabel2.setText("Nombres");

        jLabel3.setText("Apellidos");

        jLabel9.setText("Correo");

        jLabel5.setText("Dirección");

        jLabel6.setText("Estado Civil");

        jLabel1.setText("DNI");

        jLabel4.setText("Edad");

        jLabel8.setText("Teléfono");

        jLabel7.setText("Género");

        tf_cedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_cedulaKeyTyped(evt);
            }
        });

        tf_nombres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tf_nombresKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_nombresKeyTyped(evt);
            }
        });

        tf_apellidos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_apellidosKeyTyped(evt);
            }
        });

        tf_edad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_edadKeyTyped(evt);
            }
        });

        tf_direccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_direccionKeyTyped(evt);
            }
        });

        tf_estado_civil.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_estado_civilKeyTyped(evt);
            }
        });

        cb_genero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Masculino", "Femenino" }));

        tf_telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_telefonoActionPerformed(evt);
            }
        });
        tf_telefono.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tf_telefonoKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(30, 30, 30)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cb_genero, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(tf_nombres, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf_apellidos, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(tf_edad, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(tf_direccion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tf_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(tf_estado_civil, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(43, 43, 43)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tf_correo, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_cedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_nombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_edad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tf_estado_civil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cb_genero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tf_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tf_correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Nuevo / Modificar", jPanel3);

        jPanel1.setBackground(new java.awt.Color(251, 248, 248));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        bt_guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/agregarp.png"))); // NOI18N
        bt_guardar.setText("Guardar");
        bt_guardar.setBorderPainted(false);
        bt_guardar.setContentAreaFilled(false);
        bt_guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_guardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_guardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_guardarActionPerformed(evt);
            }
        });

        bt_actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/editar.png"))); // NOI18N
        bt_actualizar.setText("Modificar");
        bt_actualizar.setContentAreaFilled(false);
        bt_actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_actualizar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_actualizar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_actualizarActionPerformed(evt);
            }
        });

        bt_eliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/eliminar.png"))); // NOI18N
        bt_eliminar.setText("Eliminar");
        bt_eliminar.setContentAreaFilled(false);
        bt_eliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_eliminar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_eliminar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_eliminarActionPerformed(evt);
            }
        });

        bt_limpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/nuevav.png"))); // NOI18N
        bt_limpiar.setText("Nuevo");
        bt_limpiar.setContentAreaFilled(false);
        bt_limpiar.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        bt_limpiar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        bt_limpiar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        bt_limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_limpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bt_eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(bt_actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(bt_guardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(bt_limpiar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bt_limpiar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addComponent(bt_guardar)
                .addGap(28, 28, 28)
                .addComponent(bt_actualizar)
                .addGap(29, 29, 29)
                .addComponent(bt_eliminar)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1112, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private int validarCampos(){
        int aux = 0;
   
        if(tf_cedula.getText().isEmpty()) aux = 1;
        if(tf_nombres.getText().isEmpty()) aux = 1;
        if(tf_apellidos.getText().isEmpty()) aux = 1;
        if(tf_edad.getText().isEmpty()) aux = 1;
        if(tf_direccion.getText().isEmpty()) aux = 1;
        if(tf_estado_civil.getText().isEmpty()) aux = 1;
        if(tf_telefono.getText().isEmpty()) aux = 1;
        if(tf_correo.getText().isEmpty()) aux = 1;
        
        if (aux == 1)
            JOptionPane.showMessageDialog(null, "No deben existir campos vacios", "Mensaje", JOptionPane.WARNING_MESSAGE);
        
        return aux;
    }
    
    private void bt_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_guardarActionPerformed
        int resp = validarCampos();
        
        if(resp == 0){
            int fila = tabla.getSelectedRowCount();
            if (fila < 1){
                guardar();
            }
            else{
                actualizar();
            }
        }
        
        
    }//GEN-LAST:event_bt_guardarActionPerformed

    private void bt_limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_limpiarActionPerformed
        limpiar();
        jTabbedPane1.setSelectedIndex(1);
        tf_cedula.requestFocus();
        bt_guardar.setEnabled(true);
        bt_actualizar.setEnabled(false);
        bt_eliminar.setEnabled(false);
        activar();
    }//GEN-LAST:event_bt_limpiarActionPerformed

    private void bt_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_actualizarActionPerformed
        int fila = tabla.getSelectedRowCount();
        if (fila < 1){
            JOptionPane.showMessageDialog(null, "Seleccione un registro de la tabla");
        }
        
        else{
            int row = tabla.getSelectedRow(); 
            tf_cedula.setText(tabla.getValueAt(row, 0).toString());
            tf_apellidos.setText(tabla.getValueAt(row, 1).toString());
            tf_nombres.setText(tabla.getValueAt(row, 2).toString());
            tf_edad.setText(tabla.getValueAt(row, 3).toString());
            tf_direccion.setText(tabla.getValueAt(row, 4).toString());
            tf_estado_civil.setText(tabla.getValueAt(row, 5).toString());
            cb_genero.setSelectedItem(tabla.getValueAt(row, 6).toString());
            tf_telefono.setText(tabla.getValueAt(row, 7).toString());
            tf_correo.setText(tabla.getValueAt(row, 8).toString());
            activar();
            jTabbedPane1.setSelectedIndex(1);
            bt_guardar.setEnabled(true);
            bt_actualizar.setEnabled(false);
            bt_eliminar.setEnabled(false);
        }
        
        
    }//GEN-LAST:event_bt_actualizarActionPerformed

    private void bt_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_eliminarActionPerformed
        int fila = tabla.getSelectedRowCount();
        if (fila < 1){
            JOptionPane.showMessageDialog(null, "Seleccione un registro de la tabla");
        }
        else{
            int resp = JOptionPane.showConfirmDialog(null, "¿Está seguro que desea eliminar?","Eliminar Estudiante", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(resp==0){
                if (CP.elimiarEstudiante(tabla.getValueAt(tabla.getSelectedRow(), 0).toString()) > 0){
                    listar();
                    limpiar();
                    desactivar();
                }
            }
        }
    }//GEN-LAST:event_bt_eliminarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        bt_actualizar.setEnabled(true);
        bt_eliminar.setEnabled(true);
        bt_guardar.setEnabled(false);
        desactivar();
    }//GEN-LAST:event_tablaMouseClicked

    private void tf_nombresKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_nombresKeyReleased
        
    }//GEN-LAST:event_tf_nombresKeyReleased

    private void tf_cedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_cedulaKeyTyped
        if (tf_cedula.getText().length() >= 8 ) {      
             evt.consume();
        }
        char validar = evt.getKeyChar();
        
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo números");
        }
    }//GEN-LAST:event_tf_cedulaKeyTyped

    private void tf_nombresKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_nombresKeyTyped
        char validar = evt.getKeyChar();
        
        if(Character.isDigit(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo letras");
        }
    }//GEN-LAST:event_tf_nombresKeyTyped

    private void tf_apellidosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_apellidosKeyTyped
        char validar = evt.getKeyChar();
        
        if(Character.isDigit(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo letras");
        }
    }//GEN-LAST:event_tf_apellidosKeyTyped

    private void tf_edadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_edadKeyTyped
        char validar = evt.getKeyChar();
        
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo números");
        }
    }//GEN-LAST:event_tf_edadKeyTyped

    private void tf_direccionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_direccionKeyTyped
        
    }//GEN-LAST:event_tf_direccionKeyTyped

    private void tf_estado_civilKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_estado_civilKeyTyped
        char validar = evt.getKeyChar();
        
        if(Character.isDigit(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo letras");
        }
    }//GEN-LAST:event_tf_estado_civilKeyTyped

    private void tf_telefonoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tf_telefonoKeyTyped
        
        if (tf_telefono.getText().length() >= 9) {
            evt.consume();
            
        }
        
        char validar = evt.getKeyChar();
        
        if(Character.isLetter(validar)){
            getToolkit().beep();
            evt.consume();
            JOptionPane.showMessageDialog(null, "Ingrese sólo números");
        }
    }//GEN-LAST:event_tf_telefonoKeyTyped

    private void tf_telefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_telefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tf_telefonoActionPerformed

    private void guardar(){
        String genero;
        String cedula = tf_cedula.getText();
        String nombres = tf_nombres.getText();
        String apellidos = tf_apellidos.getText();
        int edad = Integer.parseInt(tf_edad.getText());
        String direccion = tf_direccion.getText();
        String estado_civil = tf_estado_civil.getText();
        String combo_box = (String)cb_genero.getSelectedItem();
        if(combo_box.equals("Masculino")){
            genero = "M";
        }
        else{
            genero = "F";
        }
        
        String telefono = tf_telefono.getText();
        String correo = tf_correo.getText();
        
        int respuesta = CP.registrarEstudiante(cedula,nombres,apellidos,edad,direccion,estado_civil,genero,telefono,correo);
        
        if(respuesta > 0){
            listar();
            limpiar();
            jTabbedPane1.setSelectedIndex(0);
            desactivar();
            bt_guardar.setEnabled(false);
        }
        
    }
    
    private void actualizar(){
        int row = tabla.getSelectedRow();
        String cedula_tabla = tabla.getValueAt(row, 0).toString();
        String genero;
        
        String cedula = tf_cedula.getText();
        String nombres = tf_nombres.getText();
        String apellidos = tf_apellidos.getText();
        int edad = Integer.parseInt(tf_edad.getText());
        String direccion = tf_direccion.getText();
        String estado_civil = tf_estado_civil.getText();

        String combo_box = (String)cb_genero.getSelectedItem();
        if(combo_box.equals("Masculino")){
            genero = "M";
        }
        else{
            genero = "F";
        }
        String telefono = tf_telefono.getText();
        String correo = tf_correo.getText();
        
        int respuesta = CP.actualizarEstudiante(cedula,nombres,apellidos,edad,direccion,estado_civil,genero,telefono,correo,cedula_tabla);
        if(respuesta > 0){
            listar();
            limpiar();
            jTabbedPane1.setSelectedIndex(0);
            desactivar();
            bt_guardar.setEnabled(false);
        }
    }

    private void limpiar(){
        tf_cedula.setText("");
        tf_nombres.setText("");
        tf_apellidos.setText("");
        tf_edad.setText("");
        tf_direccion.setText("");
        tf_estado_civil.setText("");
        cb_genero.setSelectedIndex(0);
        tf_telefono.setText("");
        tf_correo.setText("");
        tabla.clearSelection();
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_actualizar;
    private javax.swing.JButton bt_eliminar;
    private javax.swing.JButton bt_guardar;
    private javax.swing.JButton bt_limpiar;
    private javax.swing.JComboBox<String> cb_genero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tabla;
    private javax.swing.JTextField tf_apellidos;
    public javax.swing.JTextField tf_cedula;
    private javax.swing.JTextField tf_correo;
    private javax.swing.JTextField tf_direccion;
    private javax.swing.JTextField tf_edad;
    private javax.swing.JTextField tf_estado_civil;
    private javax.swing.JTextField tf_nombres;
    private javax.swing.JTextField tf_telefono;
    // End of variables declaration//GEN-END:variables
}
