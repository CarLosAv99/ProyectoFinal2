package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Niveles {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_NIVEL = "SELECT * FROM semestre order by sem_id_semestre";
    private final String SQL_INSERT_NIVEL = "INSERT INTO semestre (sem_nombre)values (?)";
    
    public Niveles(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosNiveles(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("ID");
        DT.addColumn("Niveles");
        return DT;
    }
    
    public DefaultTableModel getDatosNiveles(){
        try {
            setTitulosNiveles();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_NIVEL);
            RS = PS.executeQuery();
            Object[] fila = new Object[2];
            while(RS.next()){
                fila[0] = RS.getInt(1);
                fila[1] = RS.getString(2);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarNivel(String nombre){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_NIVEL);
            PS.setString(1, nombre);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Nivel Registrado Correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar la jornada.");
            System.err.println("Error al registrar carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int actualizarNivel(String nombre, int id){
        String SQL = "UPDATE semestre SET sem_nombre = '"+nombre+"' where sem_id_semestre ="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Nivel Modificado con Éxito");
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar los datos" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int elimiarNivel(int id){
        String SQL = "DELETE from semestre WHERE sem_id_semestre="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Nivel Eliminado.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No es posible eliminar rl nivel.");
            System.err.println("Error al eliminar estudiante." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
}
