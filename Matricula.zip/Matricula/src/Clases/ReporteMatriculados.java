package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class ReporteMatriculados {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_REPORTEM = "SELECT est_cedula, CONCAT(est_apellidos, ' ', est_nombres), car_nombre, sem_nombre, CONCAT(per_f_in, ' Hasta ', per_f_fin) from estudiante INNER JOIN matricula ON est_cedula = mat_id_estudiante INNER JOIN semestre ON mat_id_semestre = sem_id_semestre INNER JOIN periodo_ac ON mat_id_periodo = per_id_periodo INNER JOIN carrera ON mat_id_carrera = car_id_carrera";
    
    
    public ReporteMatriculados(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosReporteM(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("ID");
        DT.addColumn("Nombre de Estudiante");
        DT.addColumn("Carrera");
        DT.addColumn("Nivel");
        DT.addColumn("Período");
        return DT;
    }
    
    public DefaultTableModel getDatosReporteM(){
        try {
            setTitulosReporteM();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_REPORTEM);
            RS = PS.executeQuery();
            Object[] fila = new Object[5];
            while(RS.next()){
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                fila[3] = RS.getString(4);  
                fila[4] = RS.getString(5);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al generar reporte."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
}
