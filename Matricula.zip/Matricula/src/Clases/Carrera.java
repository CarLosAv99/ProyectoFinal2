package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Carrera {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_CARRERA = "SELECT * FROM carrera order by car_id_carrera";
    private final String SQL_INSERT_CARRERA = "INSERT INTO carrera (car_nombre)values (?)";
    
    public Carrera(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosCarrera(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("ID");
        DT.addColumn("Nombre de la Carrera");
        return DT;
    }
    
    public DefaultTableModel getDatosCarrera(){
        try {
            setTitulosCarrera();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_CARRERA);
            RS = PS.executeQuery();
            Object[] fila = new Object[2];
            while(RS.next()){
                fila[0] = RS.getInt(1);
                fila[1] = RS.getString(2);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarCarrera(String nombre){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_CARRERA);
            PS.setString(1, nombre);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Carrera Registrada Correctamente.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar la carrera.");
            System.err.println("Error al registrar carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int actualizarCarrera(String nombre, int id){
        String SQL = "UPDATE carrera SET car_nombre = '"+nombre+"' where car_id_carrera ="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Carrera Modificada con Éxito");
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar los datos" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int elimiarCarrera(int id){
        String SQL = "DELETE from carrera WHERE car_id_carrera="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Carrera Eliminada.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No es posible eliminar la carrera.");
            System.err.println("Error al eliminar estudiante." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
}
