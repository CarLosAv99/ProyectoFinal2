package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {
    private PreparedStatement PS;
    private ResultSet RS;
    private final Conectar CN;
    
    public Login(){
        PS = null;
        CN = new Conectar();
    }
    
    public int validarUsuario(String usuario, String contraseña){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT COUNT(log_usuario) from login where log_usuario = '"+usuario+ "' AND log_contraseña = '"+contraseña+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extrare id de Carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
}
