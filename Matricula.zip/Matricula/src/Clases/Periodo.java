package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Periodo {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_PERIODO = "SELECT * FROM periodo_ac";
    private final String SQL_INSERT_PERIODO = "INSERT INTO periodo_ac (per_f_in,per_f_fin) values (?,?)";
    
    public Periodo(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosPeriodo(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("ID");
        DT.addColumn("Fecha inicio");
        DT.addColumn("Fecha fin");
        return DT;
    }
    
    public DefaultTableModel getDatosPeriodo(){
        try {
            setTitulosPeriodo();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_PERIODO);
            RS = PS.executeQuery();
            Object[] fila = new Object[3];
            while(RS.next()){
                fila[0] = RS.getInt(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarPeriodo(String fecha_i, String fecha_f){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_PERIODO);
            PS.setString(1, fecha_i);
            PS.setString(2, fecha_f);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Período Registrado Correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar el periodo.");
            System.err.println("Error al registrar periodo." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    
    public int eliminarPeriodo(int id){
        String SQL = "DELETE from periodo_ac WHERE per_id_periodo="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Periodo Eliminado.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No es posible eliminar al estudiante.");
            System.err.println("Error al eliminar estudiante." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
   
}
