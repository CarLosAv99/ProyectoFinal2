package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Asignatura {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_ASIGNATURA = "SELECT asi_id_asignatura, asi_nombre, sem_nombre, car_nombre from asignatura INNER JOIN semestre ON sem_id_semestre = asi_id_semestre INNER JOIN carrera_asignatura ON asi_id_asignatura = ca_id_asignatura INNER JOIN carrera ON ca_id_carrera = car_id_carrera";
    private final String SQL_INSERT_ASIGNATURA = "INSERT INTO asignatura (asi_nombre, asi_id_semestre) values (?,?)";
    private final String SQL_INSERT_ASIGNATURA_CARRERA = "INSERT INTO carrera_asignatura (ca_id_carrera, ca_id_asignatura) values (?,?)";
    
    public Asignatura(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosAsignatura(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("ID");
        DT.addColumn("Nombre de la Asignatura");
        DT.addColumn("Carrera");
        DT.addColumn("Nivel");
        return DT;
    }
    
    public DefaultTableModel getDatosAsignatura(){
        try {
            setTitulosAsignatura();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_ASIGNATURA);
            RS = PS.executeQuery();
            Object[] fila = new Object[4];
            while(RS.next()){
                fila[0] = RS.getInt(1);
                fila[1] = RS.getString(2);
                fila[3] = RS.getString(3);
                fila[2] = RS.getString(4);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarAsignatura(String nombre, int id_semestre){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_ASIGNATURA);
            PS.setString(1, nombre);
            PS.setInt(2, id_semestre);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Asignatura Registrada Correctamente.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar la asignatura.");
            System.err.println("Error al registrar asignatura." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int registrarAsignatura_Carrera(int id_carrera, int id_asig){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_ASIGNATURA_CARRERA);
            PS.setInt(1, id_carrera);
            PS.setInt(2, id_asig);
 
            res = PS.executeUpdate();
            if(res > 0){
                System.out.println("Asignatura-Carrera agregada con exito.");
            }
        } catch (SQLException e) {
            System.err.println("Error al registrar asignatura-carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int actualizarAsignatura(String nombre, int id_nivel, String id_tabla){
        String SQL = "UPDATE asignatura SET asi_nombre='"+nombre+"',asi_id_semestre="+id_nivel+" WHERE asi_id_asignatura='"+id_tabla+"'";
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Asignatura Modificado con Éxito");
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar los datos" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int eliminarAsignatura(int id){
        String SQL = "DELETE from asignatura WHERE asi_id_asignatura="+id;
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Asignatura Eliminada.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No es posible eliminar la asignatura.");
            System.err.println("Error al eliminar estudiante." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public void carreras_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT car_nombre FROM carrera ORDER BY car_nombre ASC";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
           //LLenamos nuestro ComboBox
           //cbox_paises.addItem("Seleccione una opción");

           while(RS.next()){
               cbox.addItem(RS.getString("car_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public void niveles_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT sem_nombre FROM semestre ORDER BY sem_id_semestre ASC";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
           //LLenamos nuestro ComboBox
           //cbox_paises.addItem("Seleccione una opción");

           while(RS.next()){
               cbox.addItem(RS.getString("sem_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public int idAsignatura(String nombre){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT asi_id_asignatura from asignatura where asi_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extraer ID de la asignatura." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int idNivel(String nombre){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT sem_id_semestre from semestre where sem_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extraer ID del nivel." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int idCarrera(String nombre){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT car_id_carrera from carrera where car_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extrare id de Carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
}
