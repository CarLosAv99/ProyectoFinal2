package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Estudiantes {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_ESTUDIANTE = "SELECT * FROM estudiante order by est_apellidos";
    private final String SQL_INSERT_ESTUDIANTE = "INSERT INTO estudiante values (?,?,?,?,?,?,?,?,?)";
    
    public Estudiantes(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosEstudiante(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("DNI");
        DT.addColumn("Apellidos");
        DT.addColumn("Nombres");
        DT.addColumn("Edad");
        DT.addColumn("Dirección");
        DT.addColumn("Estado Civil");
        DT.addColumn("Género");
        DT.addColumn("Teléfono");
        DT.addColumn("Correo");
        return DT;
    }
    
    public DefaultTableModel getDatosEstudiante(){
        try {
            setTitulosEstudiante();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_ESTUDIANTE);
            RS = PS.executeQuery();
            Object[] fila = new Object[9];
            while(RS.next()){
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(3);
                fila[2] = RS.getString(2);
                fila[3] = RS.getInt(4);  
                fila[4] = RS.getString(5);
                fila[5] = RS.getString(6);
                fila[6] = RS.getString(7);
                fila[7] = RS.getString(8);
                fila[8] = RS.getString(9);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarEstudiante(String cedula, String nombres, String apellidos, int edad, String direccion, String estado_civil, String genero, String telefono, String correo){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_ESTUDIANTE);
            PS.setString(1, cedula);
            PS.setString(2, nombres);
            PS.setString(3, apellidos);
            PS.setInt(4, edad);
            PS.setString(5, direccion);
            PS.setString(6, estado_civil);
            PS.setString(7, genero);
            PS.setString(8, telefono);
            PS.setString(9, correo);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Estudiante Registrado Correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar al estudiante.");
            System.err.println("Error al registrar estudiante" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int actualizarEstudiante(String cedula, String nombres, String apellidos, int edad, String direccion, String estado_civil, String genero, String telefono, String correo, String cedula_anterior){
        String SQL = "UPDATE estudiante SET est_cedula='"+cedula+"',est_nombres='"+nombres+"',est_apellidos='"+apellidos+"',est_edad="+edad+",est_direccion='"+direccion+"',est_estado_civil='"+estado_civil+"',est_genero='"+genero+"',est_telefono='"+telefono+"' WHERE est_cedula='"+cedula_anterior+"'";
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Estudiante Modificado con Éxito");
            }
        } catch (SQLException e) {
            System.err.println("Error al modificar los datos" +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int elimiarEstudiante(String cedula){
        String SQL = "DELETE from estudiante WHERE est_cedula='"+cedula+"'";
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Estudiante Eliminado.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No es posible eliminar al estudiante.");
            System.err.println("Error al eliminar estudiante." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int cedulaExiste(String cedula){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT count(est_cedula) from estudiante where est_cedula='"+cedula+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al verificar si existe numero de cedula." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
}
