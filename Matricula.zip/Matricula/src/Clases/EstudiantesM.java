package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;


public class EstudiantesM {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_ESTUDIANTE = "SELECT est_cedula, est_apellidos, est_nombres from estudiante INNER JOIN matricula ON est_cedula = mat_id_estudiante";

    public EstudiantesM(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosEstudiante(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("DNI");
        DT.addColumn("Apellidos");
        DT.addColumn("Nombres");
        return DT;
    }
    
    public DefaultTableModel getDatosEstudiantes(){
        try {
            setTitulosEstudiante();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_ESTUDIANTE);
            RS = PS.executeQuery();
            Object[] fila = new Object[3];
            while(RS.next()){
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
}
