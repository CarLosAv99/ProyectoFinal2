package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class matricula {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    private final String SQL_SELECT_ESTUDIANTE = "SELECT est_cedula, est_apellidos, est_nombres from estudiante ORDER BY est_apellidos";
    private final String SQL_INSERT_MATRICULA = "INSERT INTO matricula (mat_id_estudiante, mat_id_periodo, mat_id_semestre, mat_id_carrera) values (?,?,?,?)";
    private final String SQL_INSERT_MATRICULA_MATERIAS = "INSERT INTO matricula_asignatura (mm_id_matricula, mm_id_asignatura) values (?,?)";
    
    public matricula(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosEstudiante(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("DNI");
        DT.addColumn("Apellidos");
        DT.addColumn("Nombres");
        return DT;
    }
    
    public DefaultTableModel getDatosEstudiantes(){
        try {
            setTitulosEstudiante();
            PS = CN.getConnection().prepareStatement(SQL_SELECT_ESTUDIANTE);
            RS = PS.executeQuery();
            Object[] fila = new Object[3];
            while(RS.next()){
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                fila[2] = RS.getString(3);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los datos."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
    
    public int registrarMatricula(String cedula, int periodo, int semestre, int carrera){
        int res=0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_MATRICULA);
            PS.setString(1, cedula);
            PS.setInt(2, periodo);
            PS.setInt(3, semestre);
            PS.setInt(4, carrera);

            res = PS.executeUpdate();
            if(res > 0){
                JOptionPane.showMessageDialog(null, "Matricula Generada Correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo generar la matrícula.");
            System.err.println("Error al registrar matricula. " +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int idUltimaMatricula(){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT mat_id from matricula order by mat_id desc limit 1");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extraer ultimo id Matricula." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public void guardarMatricula_Materias(String id_Materia, int id_matricula){
        int res = 0;
        try {
            PS = CN.getConnection().prepareStatement(SQL_INSERT_MATRICULA_MATERIAS);
            PS.setInt(1, id_matricula);
            PS.setString(2, id_Materia);

            PS.executeUpdate();
            if(res > 0){
                System.out.println("Matricula_Materias generado correctamente");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo generar la matrícula.");
            System.err.println("Error al registrar matricula. " +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
    }
    
    public void carreras_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT car_nombre FROM carrera ORDER BY car_nombre ASC";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
           //LLenamos nuestro ComboBox
           //cbox_paises.addItem("Seleccione una opción");

           while(RS.next()){
               cbox.addItem(RS.getString("car_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public void niveles_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT sem_nombre FROM semestre ORDER BY sem_id_semestre ASC";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
           //LLenamos nuestro ComboBox
           //cbox_paises.addItem("Seleccione una opción");

           while(RS.next()){
               cbox.addItem(RS.getString("sem_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public void materias_disponibles(JComboBox cbox, String carrera, String nivel){
        //Creamos la Consulta SQL
        String SQL = "SELECT asi_nombre FROM asignatura INNER JOIN semestre ON asi_id_semestre = sem_id_semestre INNER JOIN carrera_asignatura ON asi_id_asignatura = ca_id_asignatura INNER JOIN carrera ON ca_id_carrera = car_id_carrera WHERE car_nombre = '"+carrera+"' AND sem_nombre = '"+nivel+"'";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();
           //LLenamos nuestro ComboBox
           //cbox_paises.addItem("Seleccione una opción");

           while(RS.next()){
               cbox.addItem(RS.getString("asi_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public void periodos_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT per_id_periodo, CONCAT(per_f_in,' Hasta ',per_f_fin) as periodo FROM periodo_ac";
        String SQL2 = "SELECT COUNT(per_id_periodo) FROM periodo_ac";
        int n = 1, i = 1;
        
        
        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL2);
            RS = PS.executeQuery();

            while(RS.next()){
                n = RS.getInt(1);
            }
            Ventanas.Matricula.id_periodo = new int[n+1];
            
            
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();

            while(RS.next()){
                cbox.addItem(RS.getString("periodo"));
                Ventanas.Matricula.id_periodo[i] = RS.getInt("per_id_periodo");
                i++;
            }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public void jornadas_disponibles(JComboBox cbox){
        //Creamos la Consulta SQL
        String SQL = "SELECT jor_nombre FROM jornada ORDER BY jor_nombre ASC";

        //Establecemos bloque try-catch-finally
        try {
            PS = CN.getConnection().prepareStatement(SQL);
            RS = PS.executeQuery();

           while(RS.next()){
               cbox.addItem(RS.getString("jor_nombre"));
           }
        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, e);

        }finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
    }
    
    public int idSemestre(String nombre){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT sem_id_semestre from semestre where sem_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al extraer id Semestre." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int idCarrera(String nombre){
        int res=0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT car_id_carrera from carrera where car_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al verificar si existe id Carrera." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public String idMateria(String nombre){
        String res = "";
        try{
            PS = CN.getConnection().prepareStatement("SELECT asi_id_asignatura from asignatura where asi_nombre='"+nombre+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getString(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al verificar si existe id Materia." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
    public int cedulaRepetida(String cedula){
        int res = 0;
        try{
            PS = CN.getConnection().prepareStatement("SELECT COUNT(mat_id) from matricula where mat_id_estudiante='"+cedula+"'");
            RS = PS.executeQuery();

            while(RS.next()){
                res = RS.getInt(1);
            } 
        } catch (SQLException e) {
            System.err.println("Error al verificar si existe id Materia." +e.getMessage());
        } finally{
            PS = null;
            CN.desconectar();
        }
        return res;
    }
    
}
