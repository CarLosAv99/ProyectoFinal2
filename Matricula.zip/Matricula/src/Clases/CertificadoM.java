package Clases;

import Controlador.Conectar;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class CertificadoM {
    private PreparedStatement PS;
    private DefaultTableModel DT;
    private ResultSet RS;
    private final Conectar CN;
    
    public CertificadoM(){
        PS = null;
        CN = new Conectar();
    }
    
    private DefaultTableModel setTitulosCertificado(){
        DT = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            
        };
        DT.addColumn("Asignatura");
        DT.addColumn("Nivel");
        return DT;
    }
    
    public DefaultTableModel getDatosCertificado(String cedula){
        try {
            setTitulosCertificado();
            PS = CN.getConnection().prepareStatement("SELECT asi_nombre, sem_nombre FROM asignatura INNER JOIN matricula_asignatura ON asi_id_asignatura = mm_id_asignatura INNER JOIN matricula ON mm_id_matricula = mat_id INNER JOIN semestre ON mat_id_semestre = sem_id_semestre WHERE mat_id_estudiante ='"+cedula+"'");
            RS = PS.executeQuery();
            Object[] fila = new Object[2];
            while(RS.next()){
                fila[0] = RS.getString(1);
                fila[1] = RS.getString(2);
                DT.addRow(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al generar certificado."+e.getMessage());
        } finally{
            PS = null;
            RS = null;
            CN.desconectar();
        }
        return DT;
    }
}
